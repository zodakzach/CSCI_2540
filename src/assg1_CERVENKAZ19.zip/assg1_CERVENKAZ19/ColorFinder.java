package assg1_CERVENKAZ19;

/*Author: Zachary Cervenka
 *Color Finder code that searches a string and finds if a color is in it.
 */

import java.util.Scanner;

public class ColorFinder {
	
	public static void main (String[] args) 
	{
		System.out.println("Enter a Sentence: ");
		Scanner keyboard = new Scanner(System.in);
		String userSentence;
		String s1;
		userSentence = keyboard.nextLine();
		//converts the users sentence to all lower case to make it easier to compare
		s1 = userSentence.toLowerCase();
		
		if(s1.indexOf("green") >= 0 || s1.indexOf("red") >= 0 || s1.indexOf("blue") >= 0)
		{
			//finds the index of the substrings green, red, and blue 
			//if that index is greater than -1 then an additive color was found
			System.out.println("Additive primary color found.");
		}
		else if(s1.indexOf("yellow") >= 0 || s1.indexOf("cyan") >= 0 || s1.indexOf("magenta") >= 0) 
		{
			//if no additive colors are found 
			//it then searches for subtractive colors and if one is found it prints this to screen
			System.out.println("Subtractive primary color found.");
		}
		else 
		{
			//if no additive or subtractive primary colors are found
			System.out.println("No primary colors found.");
		}
		
	}

}
